# 登录API测试说明

## 安装依赖

```bash
pip install -r requirements.txt
```

## 测试文件说明

- `decryption_filter.py` - 加解密模块
- `test_login_api.py` - 登录API测试脚本
- `pytest.ini` - pytest配置文件

## 执行方式

### 方式1: 使用pytest执行（推荐）

```bash
# 执行所有测试（跳过标记为skip的测试）
pytest test_login_api.py -v

# 强制执行特定测试（即使标记为skip）
pytest test_login_api.py::TestLoginAPI::test_login_with_encrypted_data -v -s --runxfail

# 执行加密验证测试
pytest test_login_api.py::TestLoginAPI::test_verify_encryption -v -s --runxfail
```

### 方式2: 直接运行Python脚本

```bash
python test_login_api.py
```

## 测试用例

1. **test_login_with_encrypted_data** - 正常登录测试
   - 使用正确的账号密码
   - 数据加密后发送
   - 响应解密验证

2. **test_login_with_wrong_password** - 错误密码测试
   - 使用错误的密码
   - 验证登录失败

3. **test_verify_encryption** - 加密功能验证
   - 验证加解密正确性
   - 不发送网络请求

## 注意事项

- 测试需要在内网环境执行
- 默认跳过网络请求测试，需要手动指定执行
- SSL证书验证已关闭（verify=False）

## 请求示例

原始数据:
```json
{
  "account": "18818881888",
  "pwd": "O4zAs9Mz4aoYOirIST4Xyg==",
  "internationalCode": "86"
}
```

加密后请求体:
```json
{
  "data": "加密后的base64字符串"
}
```

请求头:
```
Content-Type: application/json
X-Encrypted: true
```