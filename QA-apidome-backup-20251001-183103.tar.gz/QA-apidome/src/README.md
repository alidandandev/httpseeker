# 加密HTTP客户端

基于httpx的自动加密解密HTTP客户端，支持同步和异步请求。

## 特性

- ✅ 自动加密请求数据
- ✅ 自动解密响应数据
- ✅ 支持同步和异步请求
- ✅ 基于httpx，性能优秀
- ✅ 支持上下文管理器
- ✅ 完整的类型提示
- ✅ 灵活的配置选项

## 安装依赖

```bash
pip install -r requirements.txt
```

## 快速开始

### 同步请求

```python
from src.encrypted_client import EncryptedHTTPClient

# 创建客户端
client = EncryptedHTTPClient(
    base_url="https://api.example.com",
    encryption_enabled=True
)

# 发送加密的POST请求
data = {
    "username": "user",
    "password": "pass"
}
response = client.post("/login", data=data)

# 响应自动解密
print(response["data"])

# 记得关闭客户端
client.close()
```

### 使用上下文管理器（推荐）

```python
from src.encrypted_client import EncryptedHTTPClient

with EncryptedHTTPClient(
    base_url="https://api.example.com",
    encryption_enabled=True
) as client:
    response = client.post("/login", data={"user": "test"})
    print(response["data"])
# 自动关闭
```

### 异步请求

```python
import asyncio
from src.encrypted_client import AsyncEncryptedHTTPClient

async def main():
    async with AsyncEncryptedHTTPClient(
        base_url="https://api.example.com",
        encryption_enabled=True
    ) as client:
        response = await client.post("/login", data={"user": "test"})
        print(response["data"])

asyncio.run(main())
```

## API参考

### EncryptedHTTPClient

同步加密HTTP客户端。

#### 初始化参数

- `base_url` (str): 基础URL
- `encryption_enabled` (bool): 是否启用加密，默认True
- `encryption_key` (str): 加密密钥，可选
- `timeout` (int): 请求超时时间（秒），默认30
- `verify_ssl` (bool): 是否验证SSL证书，默认True
- `headers` (dict): 默认请求头
- `proxies` (dict): 代理设置

#### 方法

- `get(url, **kwargs)`: GET请求
- `post(url, data=None, **kwargs)`: POST请求
- `put(url, data=None, **kwargs)`: PUT请求
- `delete(url, **kwargs)`: DELETE请求
- `patch(url, data=None, **kwargs)`: PATCH请求
- `request(method, url, data=None, **kwargs)`: 通用请求方法
- `close()`: 关闭客户端

### AsyncEncryptedHTTPClient

异步版本，方法与同步版本相同，但都是异步方法。

## 响应格式

所有请求返回统一的响应格式：

```python
{
    "status_code": 200,          # HTTP状态码
    "headers": {...},             # 响应头
    "data": {...},               # 响应数据（自动解密）
    "is_json": True,             # 是否为JSON响应
    "error": None                # 错误信息（如果有）
}
```

## 测试

运行测试：

```bash
# 运行所有测试
pytest src/test_encrypted_client.py -v

# 运行示例
python src/example_usage.py
```

## 注意事项

1. 请求数据会自动加密成 `{"data": "encrypted_string"}` 格式
2. 响应中的 `data` 字段会自动解密
3. 加密请求会自动添加 `X-Encrypted: true` 请求头
4. 支持token类型的响应数据（解密后非JSON格式）