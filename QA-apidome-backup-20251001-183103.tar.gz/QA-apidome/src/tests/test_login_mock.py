#!/usr/bin/env python3
"""
登录测试 - 使用模拟响应演示数据提取
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from src.json_extractor import JSONPathExtractor


def test_login_data_extraction():
    """演示如何提取登录响应数据"""

    print("=" * 60)
    print("登录数据提取示例（模拟响应）")
    print("=" * 60)

    # 模拟登录成功的响应
    mock_response = {
        "status_code": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": {
            "code": 20000,
            "msg": "success",
            "success": True,
            "data": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMzQ1LCJ1c2VybmFtZSI6InRlc3QiLCJleHAiOjE2OTk5OTk5OTl9.xxx"  # 模拟的token
        },
        "is_json": True
    }

    # 创建JSONPath提取器
    extractor = JSONPathExtractor()

    # 保存响应供后续使用
    extractor.save_response("login", mock_response)

    print("\n1. 提取登录响应的关键数据:")
    print("-" * 40)

    # 方式1: 单个提取
    code = extractor.extract(mock_response, "$.data.code", "code")
    msg = extractor.extract(mock_response, "$.data.msg", "message")
    token = extractor.extract(mock_response, "$.data.data", "token")

    print(f"   响应码: {code}")
    print(f"   消息: {msg}")
    print(f"   Token: {str(token)[:50]}...")

    # 方式2: 批量提取
    print("\n2. 批量提取多个字段:")
    print("-" * 40)

    extraction_config = {
        "code": "$.data.code",
        "message": "$.data.msg",
        "success": "$.data.success",
        "token": "$.data.data"
    }

    results = extractor.extract_multiple(mock_response, extraction_config)
    for key, value in results.items():
        display = str(value)[:50] + "..." if isinstance(value, str) and len(value) > 50 else value
        print(f"   {key}: {display}")

    # 使用提取的数据
    print("\n3. 使用提取的数据构造后续请求:")
    print("-" * 40)

    # 构造认证头
    auth_header = f"Bearer {extractor.get_variable('token')}"
    print(f"   Authorization: {auth_header[:60]}...")

    # 使用变量替换
    user_endpoint = "/api/users/${user_id}/profile"
    extractor.set_variable("user_id", "12345")  # 假设从token解析出用户ID
    actual_url = extractor.replace_variables(user_endpoint)
    print(f"   URL模板: {user_endpoint}")
    print(f"   实际URL: {actual_url}")

    # 模拟用户信息接口响应
    print("\n4. 链式调用示例 - 获取用户信息:")
    print("-" * 40)

    user_info_response = {
        "status_code": 200,
        "data": {
            "code": 20000,
            "data": {
                "userId": 12345,
                "username": "test_user",
                "email": "test@example.com",
                "roles": ["user", "admin"],
                "profile": {
                    "name": "张三",
                    "phone": "13800138000",
                    "address": "北京市朝阳区"
                }
            }
        }
    }

    # 提取用户信息
    user_data = extractor.extract_multiple(user_info_response, {
        "userId": "$.data.data.userId",
        "username": "$.data.data.username",
        "email": "$.data.data.email",
        "roles": "$.data.data.roles",
        "name": "$.data.data.profile.name",
        "phone": "$.data.data.profile.phone"
    })

    print("   提取的用户信息:")
    for key, value in user_data.items():
        print(f"     {key}: {value}")

    # 展示所有变量
    print("\n5. 所有已保存的变量:")
    print("-" * 40)
    all_vars = extractor.get_all_variables()
    for name, value in all_vars.items():
        display = str(value)[:50] + "..." if isinstance(value, str) and len(value) > 50 else value
        print(f"   ${{{name}}}: {display}")

    # 断言验证
    print("\n6. 使用JSONPath断言验证数据:")
    print("-" * 40)

    try:
        extractor.assert_path_equals(mock_response, "$.data.code", 20000)
        print("   ✓ 响应码验证通过")

        extractor.assert_path_equals(mock_response, "$.data.success", True)
        print("   ✓ 成功标志验证通过")

        # 验证token不为空
        assert extractor.get_variable("token") is not None
        print("   ✓ Token存在验证通过")

        # 验证用户角色包含admin
        extractor.assert_path_contains(user_info_response, "$.data.data.roles", "admin")
        print("   ✓ 管理员权限验证通过")

    except AssertionError as e:
        print(f"   ✗ 断言失败: {e}")

    print("\n" + "=" * 60)
    print("示例完成！")
    print("=" * 60)


if __name__ == "__main__":
    test_login_data_extraction()