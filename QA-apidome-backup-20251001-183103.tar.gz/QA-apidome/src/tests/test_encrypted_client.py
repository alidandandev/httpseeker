#!/usr/bin/env python3
"""
加密HTTP客户端测试脚本
"""

import pytest
import json
import logging
from src.encrypted_client import EncryptedHTTPClient
from src.encrypted_client import AsyncEncryptedHTTPClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestEncryptedHTTPClient:
    """加密HTTP客户端测试类"""

    @pytest.fixture
    def client(self):
        """创建测试客户端"""
        client = EncryptedHTTPClient(
            base_url="https://bofa.ye81s.com",
            encryption_enabled=True,
            verify_ssl=False,
            timeout=30
        )
        yield client
        client.close()

    @pytest.fixture
    def login_data(self):
        """登录测试数据"""
        return {
            "account": "18818881888",
            "pwd": "O4zAs9Mz4aoYOirIST4Xyg==",
            "internationalCode": "86"
        }

    def test_client_initialization(self):
        """测试客户端初始化"""
        client = EncryptedHTTPClient(
            base_url="https://example.com",
            encryption_enabled=True
        )
        assert client.base_url == "https://example.com"
        assert client.encryption_enabled is True
        assert client.filter is not None
        client.close()

    def test_prepare_request_data_with_encryption(self, client, login_data):
        """测试请求数据加密"""
        request_data, headers = client._prepare_request_data(login_data)

        # 验证返回的是加密的JSON字符串
        assert request_data is not None
        assert isinstance(request_data, str)

        # 验证加密后的格式
        encrypted_json = json.loads(request_data)
        assert "data" in encrypted_json
        assert isinstance(encrypted_json["data"], str)

        # 验证加密标识头
        assert headers.get("X-Encrypted") == "true"

    def test_prepare_request_data_without_encryption(self):
        """测试不加密的请求数据准备"""
        client = EncryptedHTTPClient(
            encryption_enabled=False
        )

        test_data = {"key": "value"}
        request_data, headers = client._prepare_request_data(test_data)

        # 验证返回的是普通JSON字符串
        assert request_data == json.dumps(test_data, ensure_ascii=False)
        assert "X-Encrypted" not in headers

        client.close()

    @pytest.mark.skip(reason="需要在内网环境执行")
    def test_login_request(self, client, login_data):
        """测试登录请求"""
        response = client.post(
            "/cdb/api/auth/login_v1",
            data=login_data
        )

        assert response is not None
        assert "status_code" in response
        assert "data" in response

        if response["is_json"]:
            data = response["data"]
            if isinstance(data, dict):
                assert "code" in data or "data" in data
                logger.info(f"登录响应: {data}")

    def test_context_manager(self):
        """测试上下文管理器"""
        with EncryptedHTTPClient(
            base_url="https://example.com"
        ) as client:
            assert client is not None
            assert client.client is not None

    @pytest.mark.asyncio
    async def test_async_client_initialization(self, client):
        """测试异步客户端初始化"""
        async with AsyncEncryptedHTTPClient(
            base_url="https://example.com",
            encryption_enabled=True
        ) as client:
            assert client.base_url == "https://example.com"
            assert client.encryption_enabled is True

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="需要在内网环境执行")
    async def test_async_login_request(self, login_data):
        """测试异步登录请求"""
        client: AsyncEncryptedHTTPClient
        async with AsyncEncryptedHTTPClient(
            base_url="https://bofa.ye81s.com",
            encryption_enabled=True,
            verify_ssl=False
        ) as client:
            response = await client.post(
                "/cdb/api/auth/login_v1",
                data=login_data
            )

            assert response is not None
            assert "status_code" in response
            logger.info(f"异步登录响应: {response}")

    def test_encryption_decryption_cycle(self, client):
        """测试加密解密循环"""
        # 准备测试数据
        original_data = {
            "test": "data",
            "number": 123,
            "nested": {"key": "value"}
        }

        # 加密数据
        encrypted, headers = client._prepare_request_data(original_data)
        assert encrypted is not None
        assert headers["X-Encrypted"] == "true"

        # 解析加密的JSON
        encrypted_json = json.loads(encrypted)
        assert "data" in encrypted_json

        # 解密数据
        decrypted = client.filter.decrypt(encrypted_json["data"])
        decrypted_data = json.loads(decrypted)

        # 验证数据一致性
        assert decrypted_data == original_data

    def test_multiple_encryption_methods(self, client):
        """测试多种数据类型的加密"""
        # 测试字典
        dict_data = {"key": "value"}
        encrypted_dict, _ = client._prepare_request_data(dict_data)
        assert encrypted_dict is not None

        # 测试字符串
        str_data = "plain text"
        encrypted_str, _ = client._prepare_request_data(str_data)
        assert encrypted_str is not None

        # 测试None
        none_data = None
        encrypted_none, _ = client._prepare_request_data(none_data)
        assert encrypted_none is None


if __name__ == "__main__":
    # 运行测试
    pytest.main([__file__, "-v", "-s"])