#!/usr/bin/env python3
"""
仅测试加密解密功能，不发送网络请求
"""

import json
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from src.encrypted_client import EncryptedHTTPClient


def test_encryption_decryption():
    """测试加密解密功能"""

    print("=" * 60)
    print("测试加密解密功能")
    print("=" * 60)

    # 创建客户端
    client = EncryptedHTTPClient(
        base_url="https://example.com",
        encryption_enabled=True
    )

    # 测试数据
    test_data = {
        "account": "18818881888",
        "pwd": "O4zAs9Mz4aoYOirIST4Xyg==",
        "internationalCode": "86"
    }

    print(f"\n原始数据: {test_data}")

    # 准备请求数据（加密）
    encrypted_data, headers = client._prepare_request_data(test_data)
    print(f"\n加密后的请求体: {encrypted_data[:100]}...")
    print(f"请求头: {headers}")

    # 解析加密后的JSON
    encrypted_json = json.loads(encrypted_data)
    print(f"\n加密后的data字段: {encrypted_json['data'][:50]}...")

    # 解密验证
    decrypted = client.filter.decrypt(encrypted_json["data"])
    decrypted_data = json.loads(decrypted)
    print(f"\n解密后的数据: {decrypted_data}")

    # 验证一致性
    assert decrypted_data == test_data, "数据不一致！"
    print("\n✅ 加密解密测试通过！")

    # 模拟响应处理
    mock_response = {
        "code": 20000,
        "msg": "success",
        "data": encrypted_json["data"],  # 使用加密的数据作为响应
        "success": True
    }

    print(f"\n模拟响应（data字段已加密）:")
    print(json.dumps({**mock_response, "data": mock_response["data"][:50] + "..."}, indent=2))

    # 解密响应中的data
    decrypted_response_data = client.filter.decrypt(mock_response["data"])
    print(f"\n解密后的响应data: {decrypted_response_data}")

    client.close()

    print("\n" + "=" * 60)
    print("所有测试通过！")
    print("=" * 60)


if __name__ == "__main__":
    test_encryption_decryption()