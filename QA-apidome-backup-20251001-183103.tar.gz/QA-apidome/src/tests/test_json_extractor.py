#!/usr/bin/env python3
"""
JSONPath提取器测试
"""

import pytest
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from src.json_extractor import JSONPathExtractor


class TestJSONPathExtractor:
    """JSONPath提取器测试类"""

    @pytest.fixture
    def extractor(self):
        """创建提取器实例"""
        return JSONPathExtractor()

    @pytest.fixture
    def sample_response(self):
        """示例响应数据"""
        return {
            "code": 20000,
            "msg": "success",
            "data": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
                "userId": 12345,
                "userInfo": {
                    "name": "张三",
                    "email": "test@example.com",
                    "roles": ["admin", "user"]
                },
                "permissions": [
                    {"id": 1, "name": "read", "enabled": True},
                    {"id": 2, "name": "write", "enabled": True},
                    {"id": 3, "name": "delete", "enabled": False}
                ]
            },
            "success": True
        }

    def test_basic_extraction(self, extractor, sample_response):
        """测试基本提取"""
        # 提取简单字段
        code = extractor.extract(sample_response, "$.code")
        assert code == 20000

        msg = extractor.extract(sample_response, "$.msg")
        assert msg == "success"

        # 提取嵌套字段
        token = extractor.extract(sample_response, "$.data.token")
        assert token == "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"

        user_name = extractor.extract(sample_response, "$.data.userInfo.name")
        assert user_name == "张三"

    def test_array_extraction(self, extractor, sample_response):
        """测试数组提取"""
        # 提取所有角色
        roles = extractor.extract(sample_response, "$.data.userInfo.roles")
        assert roles == ["admin", "user"]

        # 提取特定角色
        first_role = extractor.extract(sample_response, "$.data.userInfo.roles[0]")
        assert first_role == "admin"

        # 提取所有权限名称
        permission_names = extractor.extract(sample_response, "$.data.permissions[*].name")
        assert permission_names == ["read", "write", "delete"]

    def test_filter_extraction(self, extractor, sample_response):
        """测试过滤提取"""
        # 提取启用的权限
        enabled_perms = extractor.extract(
            sample_response,
            "$.data.permissions[?(@.enabled==true)].name"
        )
        assert enabled_perms == ["read", "write"]

        # 提取特定ID的权限
        perm_2 = extractor.extract(
            sample_response,
            "$.data.permissions[?(@.id==2)]"
        )
        # 结果可能是单个对象或列表，需要处理两种情况
        if isinstance(perm_2, list):
            assert len(perm_2) > 0
            assert perm_2[0]["name"] == "write"
        else:
            assert perm_2["name"] == "write"

    def test_variable_storage(self, extractor, sample_response):
        """测试变量存储"""
        # 提取并保存到变量
        token = extractor.extract(sample_response, "$.data.token", "auth_token")
        assert extractor.get_variable("auth_token") == token

        user_id = extractor.extract(sample_response, "$.data.userId", "user_id")
        assert extractor.get_variable("user_id") == 12345

        # 手动设置变量
        extractor.set_variable("custom_var", "custom_value")
        assert extractor.get_variable("custom_var") == "custom_value"

    def test_multiple_extraction(self, extractor, sample_response):
        """测试批量提取"""
        config = {
            "token": "$.data.token",
            "user_id": "$.data.userId",
            "user_name": "$.data.userInfo.name",
            "is_admin": {
                "path": "$.data.userInfo.roles[?(@ == 'admin')]",
                "default": False
            }
        }

        results = extractor.extract_multiple(sample_response, config)

        assert results["token"] == "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        assert results["user_id"] == 12345
        assert results["user_name"] == "张三"
        assert "admin" in results["is_admin"]

    def test_variable_replacement(self, extractor):
        """测试变量替换"""
        # 设置变量
        extractor.set_variable("user_id", 123)
        extractor.set_variable("token", "abc123")

        # 替换文本中的变量
        text = "User ${user_id} with token ${token}"
        result = extractor.replace_variables(text)
        assert result == "User 123 with token abc123"

        # 替换字典中的变量
        data = {
            "userId": "${user_id}",
            "auth": "Bearer ${token}",
            "nested": {
                "id": "${user_id}"
            }
        }
        result = extractor.replace_in_dict(data)
        assert result["userId"] == "123"
        assert result["auth"] == "Bearer abc123"
        assert result["nested"]["id"] == "123"

    def test_default_values(self, extractor, sample_response):
        """测试默认值"""
        # 不存在的路径返回默认值
        result = extractor.extract(sample_response, "$.data.notexist", default="default")
        assert result == "default"

        # 不存在的变量返回默认值
        var = extractor.get_variable("notexist", default="default_var")
        assert var == "default_var"

    def test_response_cache(self, extractor, sample_response):
        """测试响应缓存"""
        # 保存响应
        extractor.save_response("login", sample_response)

        # 从保存的响应中提取
        token = extractor.extract_from_response("login", "$.data.token", "token")
        assert token == "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        assert extractor.get_variable("token") == token

        # 获取保存的响应
        saved = extractor.get_response("login")
        assert saved == sample_response

    def test_assertions(self, extractor, sample_response):
        """测试断言功能"""
        # 成功的断言
        assert extractor.assert_path_equals(sample_response, "$.code", 20000)
        assert extractor.assert_path_contains(sample_response, "$.data.userInfo.roles", "admin")

        # 失败的断言
        with pytest.raises(AssertionError):
            extractor.assert_path_equals(sample_response, "$.code", 404)

        with pytest.raises(AssertionError):
            extractor.assert_path_contains(sample_response, "$.data.userInfo.roles", "superadmin")

    def test_json_string_input(self, extractor):
        """测试JSON字符串输入"""
        json_string = '{"name": "test", "value": 123}'

        # 从JSON字符串提取
        name = extractor.extract(json_string, "$.name")
        assert name == "test"

        value = extractor.extract(json_string, "$.value")
        assert value == 123

    def test_complex_jsonpath(self, extractor):
        """测试复杂的JSONPath表达式"""
        data = {
            "store": {
                "books": [
                    {"title": "Book1", "price": 10, "category": "fiction"},
                    {"title": "Book2", "price": 20, "category": "science"},
                    {"title": "Book3", "price": 15, "category": "fiction"}
                ]
            }
        }

        # 递归搜索
        all_prices = extractor.extract(data, "$..price")
        assert all_prices == [10, 20, 15]

        # 切片
        first_two_books = extractor.extract(data, "$.store.books[:2].title")
        assert first_two_books == ["Book1", "Book2"]

        # 复杂过滤
        cheap_fiction = extractor.extract(
            data,
            "$.store.books[?(@.category=='fiction' & @.price < 20)].title"
        )
        assert cheap_fiction == ["Book1", "Book3"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])