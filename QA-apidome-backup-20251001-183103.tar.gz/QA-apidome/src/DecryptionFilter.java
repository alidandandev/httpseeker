package cn.rh.flash.api.interceptor;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE) // 确保最先执行
@Slf4j
public class DecryptionFilter extends OncePerRequestFilter {

    @Value("${encryption.enabled:true}")
    private boolean encryptionEnabled;
    @Value("${encryption.key:your-32-byte-secure-aes-key-1234}")
    private String encryptionKey;
    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    // 显式声明为32字节密钥
    private static final String KEY = "your-32-byte-secure-aes-key-1234"; // 32字符
    private static final int IV_LENGTH = 16;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        if (encryptionEnabled && isEncryptedRequest(request)) {
            try {
                // 处理请求体解密
                String encryptedBody = StreamUtils.copyToString(request.getInputStream(), StandardCharsets.UTF_8);
                if (StringUtils.isNotBlank(encryptedBody)) {
                    JSONObject jsonObject = JSON.parseObject(encryptedBody);
                    if (jsonObject.containsKey("data") && jsonObject.get("data") instanceof String) {
                        String encryptedData = (String) jsonObject.get("data");
                        String decryptedData = decrypt(encryptedData);
                        if (StringUtils.isNotBlank(decryptedData)) {
                            // 替换请求体
                            DecryptedHttpServletRequestWrapper requestWrapper =
                                    new DecryptedHttpServletRequestWrapper(request, decryptedData);
                            // 包装响应
                            EncryptableResponseWrapper responseWrapper = new EncryptableResponseWrapper(response);
                            // 执行后续过滤器链
                            filterChain.doFilter(requestWrapper, responseWrapper);
                            // 获取原始响应体
                            String originalBody = responseWrapper.getContent();
                            // 加密 data 字段
                            String encrypted = encryptDataField(originalBody);
                            // 写回加密后的内容
                            response.setContentType("application/json;charset=UTF-8");
                            response.setContentLength(encrypted.getBytes(StandardCharsets.UTF_8).length);
                            response.getWriter().write(encrypted);
                        } else {
                            log.error("解密失败密文: {}，明文：{}", encryptedData, decryptedData);
                            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                        }
                    } else {
                        filterChain.doFilter(request, response);
                    }
                } else {
                    filterChain.doFilter(request, response);
                }
            } catch (Exception e) {
                log.error("解密失败: ", e);
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        } else {
            filterChain.doFilter(request, response);
        }
    }
    private String encryptDataField(String jsonBody) {
        try {
            JSONObject jsonObject = JSON.parseObject(jsonBody);
            if (jsonObject.containsKey("data")) {
                String dataValue = jsonObject.getString("data");
                if (StringUtils.isNotBlank(dataValue)) {
                    String encryptedData = encrypt(dataValue);
                    jsonObject.put("data", encryptedData);
                }
            }
            return jsonObject.toJSONString();
        } catch (Exception e) {
            logger.warn("响应加密失败: {}", e);
            return jsonBody; // 返回原始数据
        }
    }
    private String decrypt(String encryptedData) throws IOException {
        try {
            // 1. Base64解码
            byte[] decoded = Base64.getDecoder().decode(encryptedData);

            // 2. 分离IV和密文（假设前16字节为IV）
            byte[] iv = new byte[16];
            System.arraycopy(decoded, 0, iv, 0, iv.length);

            byte[] cipherText = new byte[decoded.length - iv.length];
            System.arraycopy(decoded, iv.length, cipherText, 0, cipherText.length);

            // 3. 创建解密器
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKeySpec keySpec = new SecretKeySpec(
                    encryptionKey.getBytes(StandardCharsets.UTF_8), "AES"
            );
            IvParameterSpec ivSpec = new IvParameterSpec(iv);

            // 4. 执行解密
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            byte[] decrypted = cipher.doFinal(cipherText);

            return new String(decrypted, StandardCharsets.UTF_8);
        } catch (Exception e) {
            // 记录异常日志
            log.error("解密失败: {}", e);
            throw new IOException("解密失败", e);
        }
    }

    /**
     * 判断当前请求是否需要解密处理
     * @param request HTTP请求对象
     * @return 是否需要解密
     */
    private boolean isEncryptedRequest(HttpServletRequest request) {
        String encryptedHeader = request.getHeader("X-Encrypted");
        return "true".equalsIgnoreCase(encryptedHeader);
    }

    public String encrypt(String plainText) throws Exception {
        // 密钥长度校验
        byte[] keyBytes = encryptionKey.getBytes(StandardCharsets.UTF_8);
        if (keyBytes.length != 32) {
            throw new IllegalArgumentException("AES密钥长度必须为32字节，当前: " + keyBytes.length);
        }

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        byte[] iv = generateIV();
        IvParameterSpec ivSpec = new IvParameterSpec(iv);

        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

        byte[] encrypted = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

        // 合并 IV + 密文并 Base64 编码
        byte[] combined = new byte[IV_LENGTH + encrypted.length];
        System.arraycopy(iv, 0, combined, 0, IV_LENGTH);
        System.arraycopy(encrypted, 0, combined, IV_LENGTH, encrypted.length);

        return Base64.getEncoder().encodeToString(combined);
    }

    private static byte[] generateIV() {
        byte[] iv = new byte[IV_LENGTH];
        new SecureRandom().nextBytes(iv);
        return iv;
    }
    
    
    private static String decrypt1(String encryptedData) throws IOException {
        try {
            // 1. Base64解码
            byte[] decoded = Base64.getDecoder().decode(encryptedData);

            // 2. 分离IV和密文（假设前16字节为IV）
            byte[] iv = new byte[16];
            System.arraycopy(decoded, 0, iv, 0, iv.length);

            byte[] cipherText = new byte[decoded.length - iv.length];
            System.arraycopy(decoded, iv.length, cipherText, 0, cipherText.length);

            // 3. 创建解密器
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKeySpec keySpec = new SecretKeySpec(
                    "your-32-byte-secure-aes-key-1234".getBytes(StandardCharsets.UTF_8), "AES"
            );
            IvParameterSpec ivSpec = new IvParameterSpec(iv);

            // 4. 执行解密
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            byte[] decrypted = cipher.doFinal(cipherText);

            return new String(decrypted, StandardCharsets.UTF_8);
        } catch (Exception e) {
            // 记录异常日志
            log.error("解密失败: {}", e);
            throw new IOException("解密失败", e);
        }
    }
    // 测试入口
    public static void main(String[] args) throws Exception {
//        String plainBody = "{\"username\":\"martin\",\"password\":\"1OjGU8CSi95H9fzsNBpgUg==\",\"ggcode\":\"\"}";
//        String encryptedBody = encrypt(plainBody);
//        System.out.println("加密结果: " + encryptedBody);
//        System.out.println("请求头: X-Encrypted: true");
        String  descryptedData = "5ipDP1CtssPFGbBmHFWGkjR9wCo0mA6Jrnq5yY2BUwQMXfQzQ9fLaLz1HCaZOgRtb95oHtpQAGCIsBiLv6mz8WPFxZtLZVuvb0iI09LV290zBEESwRthR1Waa7Wkirp+MwrzMH3pue3URvLsJv1VjEjaelbaO0XYaitSg/vx9WQ9AFdgdf0Ziw1mHd7/osV32UIH1SSclMhZkmqGM4CardSj9T6uQLbNCcLJIK4DenbYrgo/bDAHK+8Dt6Icec558S/DTWO7H52TJdfaUHU3FbdKRGPYqDbM3dxaS0okEZFySp1x/l4keB4kF2LSQw93";
        String decryptedData = decrypt1(descryptedData);
        System.out.println("解密结果: " + decryptedData);
    }
}
