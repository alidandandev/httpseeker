#!/usr/bin/env python3

import base64
import json
import logging
from typing import Optional, Dict
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DecryptionFilter:
    ALGORITHM = "AES/CBC/PKCS5Padding"
    DEFAULT_KEY = "your-32-byte-secure-aes-key-1234"
    IV_LENGTH = 16

    def __init__(self, encryption_enabled: bool = True, encryption_key: str = None):
        self.encryption_enabled = encryption_enabled
        self.encryption_key = (encryption_key or self.DEFAULT_KEY).encode('utf-8')

        if len(self.encryption_key) != 32:
            raise ValueError(f"AES密钥长度必须为32字节，当前: {len(self.encryption_key)}")

    def encrypt(self, plain_text: str) -> str:
        try:
            iv = get_random_bytes(self.IV_LENGTH)

            cipher = AES.new(self.encryption_key, AES.MODE_CBC, iv)

            plain_bytes = plain_text.encode('utf-8')
            padded_data = pad(plain_bytes, AES.block_size)
            encrypted = cipher.encrypt(padded_data)

            combined = iv + encrypted

            return base64.b64encode(combined).decode('utf-8')
        except Exception as e:
            logger.error(f"加密失败: {e}")
            raise

    def decrypt(self, encrypted_data: str) -> str:
        try:
            decoded = base64.b64decode(encrypted_data)

            iv = decoded[:16]
            cipher_text = decoded[16:]

            cipher = AES.new(self.encryption_key, AES.MODE_CBC, iv)

            decrypted = cipher.decrypt(cipher_text)
            unpadded = unpad(decrypted, AES.block_size)

            return unpadded.decode('utf-8')
        except Exception as e:
            logger.error(f"解密失败: {e}")
            raise IOError(f"解密失败: {e}")

    def encrypt_data_field(self, json_body: str) -> str:
        try:
            json_object = json.loads(json_body)
            if "data" in json_object:
                data_value = json_object["data"]
                if data_value and isinstance(data_value, str):
                    encrypted_data = self.encrypt(data_value)
                    json_object["data"] = encrypted_data
            return json.dumps(json_object, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"响应加密失败: {e}")
            return json_body

    def decrypt_data_field(self, json_body: str) -> str:
        try:
            json_object = json.loads(json_body)
            if "data" in json_object and isinstance(json_object["data"], str):
                encrypted_data = json_object["data"]
                decrypted_data = self.decrypt(encrypted_data)
                json_object["data"] = decrypted_data
                return json.dumps(json_object, ensure_ascii=False)
            return json_body
        except Exception as e:
            logger.error(f"请求解密失败: {e}")
            raise

    def process_request(self, request_body: str, headers: Dict[str, str]) -> Optional[str]:
        if not self.encryption_enabled:
            return request_body

        if not self._is_encrypted_request(headers):
            return request_body

        try:
            if request_body:
                json_object = json.loads(request_body)
                if "data" in json_object and isinstance(json_object["data"], str):
                    encrypted_data = json_object["data"]
                    decrypted_data = self.decrypt(encrypted_data)
                    if decrypted_data:
                        return decrypted_data
                    else:
                        logger.error(f"解密失败密文: {encrypted_data}")
                        return None
            return request_body
        except Exception as e:
            logger.error(f"解密失败: {e}")
            return None

    def process_response(self, response_body: str) -> str:
        if not self.encryption_enabled:
            return response_body

        try:
            return self.encrypt_data_field(response_body)
        except Exception as e:
            logger.error(f"响应加密失败: {e}")
            return response_body

    @staticmethod
    def _is_encrypted_request(headers: Dict[str, str]) -> bool:
        encrypted_header = headers.get("X-Encrypted", "").lower()
        return encrypted_header == "true"


def decrypt_static(encrypted_data: str, key: str = "your-32-byte-secure-aes-key-1234") -> str:
    try:
        key_bytes = key.encode('utf-8')
        decoded = base64.b64decode(encrypted_data)

        iv = decoded[:16]
        cipher_text = decoded[16:]

        cipher = AES.new(key_bytes, AES.MODE_CBC, iv)

        decrypted = cipher.decrypt(cipher_text)
        unpadded = unpad(decrypted, AES.block_size)

        return unpadded.decode('utf-8')
    except Exception as e:
        logger.error(f"解密失败: {e}")
        raise IOError(f"解密失败: {e}")


def encrypt_static(plain_text: str, key: str = "your-32-byte-secure-aes-key-1234") -> str:
    try:
        key_bytes = key.encode('utf-8')
        if len(key_bytes) != 32:
            raise ValueError(f"AES密钥长度必须为32字节，当前: {len(key_bytes)}")

        iv = get_random_bytes(16)

        cipher = AES.new(key_bytes, AES.MODE_CBC, iv)

        plain_bytes = plain_text.encode('utf-8')
        padded_data = pad(plain_bytes, AES.block_size)
        encrypted = cipher.encrypt(padded_data)

        combined = iv + encrypted

        return base64.b64encode(combined).decode('utf-8')
    except Exception as e:
        logger.error(f"加密失败: {e}")
        raise


if __name__ == "__main__":
    encrypted_test_data = "5ipDP1CtssPFGbBmHFWGkjR9wCo0mA6Jrnq5yY2BUwQMXfQzQ9fLaLz1HCaZOgRtb95oHtpQAGCIsBiLv6mz8WPFxZtLZVuvb0iI09LV290zBEESwRthR1Waa7Wkirp+MwrzMH3pue3URvLsJv1VjEjaelbaO0XYaitSg/vx9WQ9AFdgdf0Ziw1mHd7/osV32UIH1SSclMhZkmqGM4CardSj9T6uQLbNCcLJIK4DenbYrgo/bDAHK+8Dt6Icec558S/DTWO7H52TJdfaUHU3FbdKRGPYqDbM3dxaS0okEZFySp1x/l4keB4kF2LSQw93"

    decrypted = decrypt_static(encrypted_test_data)
    print("解密结果:", decrypted)

    filter = DecryptionFilter()

    plain_text = '{"username":"martin","password":"1OjGU8CSi95H9fzsNBpgUg==","ggcode":""}'
    encrypted = filter.encrypt(plain_text)
    print("\n加密结果:", encrypted)

    decrypted_back = filter.decrypt(encrypted)
    print("重新解密:", decrypted_back)

    test_json = '{"data":"test message","code":200}'
    encrypted_json = filter.encrypt_data_field(test_json)
    print("\nJSON加密后:", encrypted_json)

    decrypted_json = filter.decrypt_data_field(encrypted_json)
    print("JSON解密后:", decrypted_json)