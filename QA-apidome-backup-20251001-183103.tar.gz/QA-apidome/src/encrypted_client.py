#!/usr/bin/env python3
"""
加密HTTP客户端
自动处理请求加密和响应解密
"""

import json
import logging
from typing import Dict, Any, Union
import httpx
from pathlib import Path
import sys

# 添加父目录到路径以导入decryption_filter
sys.path.append(str(Path(__file__).parent.parent))
from src.decryption_filter import DecryptionFilter

logger = logging.getLogger(__name__)


class EncryptedHTTPClient:
    """
    支持自动加密解密的HTTP客户端
    """

    def __init__(
        self,
        base_url: str = "",
        encryption_enabled: bool = True,
        encryption_key: str = None,
        timeout: int = 30,
        verify_ssl: bool = True,
        headers: Dict[str, str] = None,
        proxies: Dict[str, str] = None
    ):
        """
        初始化加密HTTP客户端

        Args:
            base_url: 基础URL
            encryption_enabled: 是否启用加密
            encryption_key: 加密密钥（默认使用DecryptionFilter的默认密钥）
            timeout: 请求超时时间（秒）
            verify_ssl: 是否验证SSL证书
            headers: 默认请求头
            proxies: 代理设置
        """
        self.base_url = base_url
        self.encryption_enabled = encryption_enabled
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.proxies = proxies

        # 初始化加密过滤器
        self.filter = DecryptionFilter(
            encryption_enabled=encryption_enabled,
            encryption_key=encryption_key
        )

        # 设置默认请求头
        self.default_headers = {
            "Content-Type": "application/json",
            "User-Agent": "EncryptedHTTPClient/1.0"
        }
        if headers:
            self.default_headers.update(headers)

        # 创建httpx客户端
        self.client = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            verify=verify_ssl,
            headers=self.default_headers,
            proxies=proxies,
            follow_redirects=True
        )

    def _prepare_request_data(self, data: Union[Dict, str, None]) -> tuple[None, dict[Any, Any]] | tuple[
        str, dict[Any, Any]]:
        """
        准备请求数据（加密处理）

        Args:
            data: 原始请求数据

        Returns:
            (处理后的数据, 额外的请求头)
        """
        extra_headers = {}

        if data is None:
            return None, extra_headers

        # 如果启用加密
        if self.encryption_enabled:
            # 将数据转换为JSON字符串
            if isinstance(data, dict):
                data_str = json.dumps(data, ensure_ascii=False)
            else:
                data_str = str(data)

            # 加密数据
            encrypted_data = self.filter.encrypt(data_str)

            # 构造加密请求体
            request_body = json.dumps({"data": encrypted_data})

            # 添加加密标识头
            extra_headers["X-Encrypted"] = "true"

            logger.debug(f"原始数据: {data_str[:100]}...")
            logger.debug(f"加密后: {request_body[:100]}...")

            return request_body, extra_headers
        else:
            # 不加密，直接返回JSON字符串
            if isinstance(data, dict):
                return json.dumps(data, ensure_ascii=False), extra_headers
            return data, extra_headers

    def _process_response(self, response: httpx.Response) -> Dict[str, Any]:
        """
        处理响应数据（解密处理）

        Args:
            response: httpx响应对象

        Returns:
            处理后的响应数据
        """
        try:
            # 获取响应文本
            response_text = response.text

            # 尝试解析为JSON
            try:
                response_json = json.loads(response_text)
            except json.JSONDecodeError:
                # 不是JSON格式，直接返回
                return {
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "data": response_text,
                    "is_json": False
                }

            # 如果启用加密且响应包含data字段
            if self.encryption_enabled and "data" in response_json and isinstance(response_json["data"], str):
                try:
                    # 解密data字段
                    decrypted_data = self.filter.decrypt(response_json["data"])

                    # 尝试将解密后的数据解析为JSON
                    try:
                        response_json["data"] = json.loads(decrypted_data)
                        logger.debug("✓ 解密成功，data字段是JSON对象")
                    except json.JSONDecodeError:
                        # 不是JSON，保留为字符串（可能是token）
                        response_json["data"] = decrypted_data
                        logger.debug("✓ 解密成功，data字段是字符串（可能是token）")

                except Exception as e:
                    logger.warning(f"data字段解密失败，保留原始内容: {e}")

            return {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "data": response_json,
                "is_json": True
            }

        except Exception as e:
            logger.error(f"处理响应失败: {e}")
            return {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "data": response.text,
                "is_json": False,
                "error": str(e)
            }

    def request(
        self,
        method: str,
        url: str,
        data: Union[Dict, str, None] = None,
        headers: Dict[str, str] = None,
        params: Dict[str, str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        发送HTTP请求

        Args:
            method: 请求方法（GET, POST, PUT, DELETE等）
            url: 请求URL（相对或绝对路径）
            data: 请求数据（将被自动加密）
            headers: 额外的请求头
            params: URL查询参数
            **kwargs: 其他httpx请求参数

        Returns:
            处理后的响应数据
        """
        # 准备请求数据
        request_data, extra_headers = self._prepare_request_data(data)

        # 合并请求头
        request_headers = {}
        if headers:
            request_headers.update(headers)
        request_headers.update(extra_headers)

        # 发送请求
        logger.info(f"发送 {method} 请求到: {url}")

        try:
            if method.upper() in ["POST", "PUT", "PATCH"]:
                response = self.client.request(
                    method=method,
                    url=url,
                    content=request_data,
                    headers=request_headers,
                    params=params,
                    **kwargs
                )
            else:
                response = self.client.request(
                    method=method,
                    url=url,
                    headers=request_headers,
                    params=params,
                    **kwargs
                )

            logger.info(f"响应状态码: {response.status_code}")

            # 处理响应
            return self._process_response(response)

        except httpx.RequestError as e:
            logger.error(f"请求失败: {e}")
            raise

    def get(self, url: str, **kwargs) -> Dict[str, Any]:
        """GET请求"""
        return self.request("GET", url, **kwargs)

    def post(self, url: str, data: Union[Dict, str, None] = None, **kwargs) -> Dict[str, Any]:
        """POST请求"""
        return self.request("POST", url, data=data, **kwargs)

    def put(self, url: str, data: Union[Dict, str, None] = None, **kwargs) -> Dict[str, Any]:
        """PUT请求"""
        return self.request("PUT", url, data=data, **kwargs)

    def delete(self, url: str, **kwargs) -> Dict[str, Any]:
        """DELETE请求"""
        return self.request("DELETE", url, **kwargs)

    def patch(self, url: str, data: Union[Dict, str, None] = None, **kwargs) -> Dict[str, Any]:
        """PATCH请求"""
        return self.request("PATCH", url, data=data, **kwargs)

    def close(self):
        """关闭客户端"""
        self.client.close()

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器退出"""
        self.close()


class AsyncEncryptedHTTPClient:
    """
    异步版本的加密HTTP客户端
    """

    def __init__(
        self,
        base_url: str = "",
        encryption_enabled: bool = True,
        encryption_key: str = None,
        timeout: int = 30,
        verify_ssl: bool = True,
        headers: Dict[str, str] = None,
        proxies: Dict[str, str] = None
    ):
        """
        初始化异步加密HTTP客户端
        """
        self.base_url = base_url
        self.encryption_enabled = encryption_enabled
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.proxies = proxies

        # 初始化加密过滤器
        self.filter = DecryptionFilter(
            encryption_enabled=encryption_enabled,
            encryption_key=encryption_key
        )

        # 设置默认请求头
        self.default_headers = {
            "Content-Type": "application/json",
            "User-Agent": "AsyncEncryptedHTTPClient/1.0"
        }
        if headers:
            self.default_headers.update(headers)

        # 创建异步httpx客户端
        self.client = httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            verify=verify_ssl,
            headers=self.default_headers,
            proxies=proxies,
            follow_redirects=True
        )

    def _prepare_request_data(self, data: Union[Dict, str, None]) -> list[dict[Any, Any] | None] | tuple[
        str, dict[Any, Any]]:
        """准备请求数据（与同步版本相同）"""
        extra_headers = {}

        if data is None:
            return [None, extra_headers]

        if self.encryption_enabled:
            if isinstance(data, dict):
                data_str = json.dumps(data, ensure_ascii=False)
            else:
                data_str = str(data)

            encrypted_data = self.filter.encrypt(data_str)
            request_body = json.dumps({"data": encrypted_data})
            extra_headers["X-Encrypted"] = "true"

            logger.debug(f"原始数据: {data_str[:100]}...")
            logger.debug(f"加密后: {request_body[:100]}...")

            return request_body, extra_headers
        else:
            if isinstance(data, dict):
                return json.dumps(data, ensure_ascii=False), extra_headers
            return data, extra_headers

    def _process_response(self, response: httpx.Response) -> Dict[str, Any]:
        """处理响应数据（与同步版本相同）"""
        try:
            response_text = response.text

            try:
                response_json = json.loads(response_text)
            except json.JSONDecodeError:
                return {
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "data": response_text,
                    "is_json": False
                }

            if self.encryption_enabled and "data" in response_json and isinstance(response_json["data"], str):
                try:
                    decrypted_data = self.filter.decrypt(response_json["data"])

                    try:
                        response_json["data"] = json.loads(decrypted_data)
                        logger.debug("✓ 解密成功，data字段是JSON对象")
                    except json.JSONDecodeError:
                        response_json["data"] = decrypted_data
                        logger.debug("✓ 解密成功，data字段是字符串（可能是token）")

                except Exception as e:
                    logger.warning(f"data字段解密失败，保留原始内容: {e}")

            return {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "data": response_json,
                "is_json": True
            }

        except Exception as e:
            logger.error(f"处理响应失败: {e}")
            return {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "data": response.text,
                "is_json": False,
                "error": str(e)
            }

    async def request(
        self,
        method: str,
        url: str,
        data: Union[Dict, str, None] = None,
        headers: Dict[str, str] = None,
        params: Dict[str, str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        发送异步HTTP请求
        """
        request_data, extra_headers = self._prepare_request_data(data)

        request_headers = {}
        if headers:
            request_headers.update(headers)
        request_headers.update(extra_headers)

        logger.info(f"发送异步 {method} 请求到: {url}")

        try:
            if method.upper() in ["POST", "PUT", "PATCH"]:
                response = await self.client.request(
                    method=method,
                    url=url,
                    content=request_data,
                    headers=request_headers,
                    params=params,
                    **kwargs
                )
            else:
                response = await self.client.request(
                    method=method,
                    url=url,
                    headers=request_headers,
                    params=params,
                    **kwargs
                )

            logger.info(f"响应状态码: {response.status_code}")
            return self._process_response(response)

        except httpx.RequestError as e:
            logger.error(f"异步请求失败: {e}")
            raise

    async def get(self, url: str, **kwargs) -> Dict[str, Any]:
        """异步GET请求"""
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, data: Union[Dict, str, None] = None, **kwargs) -> Dict[str, Any]:
        """异步POST请求"""
        return await self.request("POST", url, data=data, **kwargs)

    async def put(self, url: str, data: Union[Dict, str, None] = None, **kwargs) -> Dict[str, Any]:
        """异步PUT请求"""
        return await self.request("PUT", url, data=data, **kwargs)

    async def delete(self, url: str, **kwargs) -> Dict[str, Any]:
        """异步DELETE请求"""
        return await self.request("DELETE", url, **kwargs)

    async def patch(self, url: str, data: Union[Dict, str, None] = None, **kwargs) -> Dict[str, Any]:
        """异步PATCH请求"""
        return await self.request("PATCH", url, data=data, **kwargs)

    async def close(self):
        """关闭异步客户端"""
        await self.client.aclose()

    async def __aenter__(self):
        """异步上下文管理器入口"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器退出"""
        await self.close()