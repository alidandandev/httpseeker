#!/usr/bin/env python3
"""
登录API测试脚本 - 使用EncryptedHTTPClient和JSONPath提取器
提取登录返回值供其他接口使用
"""

import pytest
import logging
import sys
from pathlib import Path

# 添加src目录到Python路径
sys.path.append(str(Path(__file__).parent.parent))
from src.encrypted_client import EncryptedHTTPClient
from src.json_extractor import JSONPathExtractor

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class TestLoginAPI:
    """登录接口测试类 - 提取返回值供后续使用"""

    # API配置
    BASE_URL = "https://bofa.ye81s.com"
    LOGIN_ENDPOINT = "/cdb/api/auth/login_v1"
    LOGOUT_ENDPOINT = "/cdb/api/auth/logout"

    # 测试账号
    TEST_ACCOUNT = "18818881888"
    TEST_PASSWORD = "O4zAs9Mz4aoYOirIST4Xyg=="
    TEST_INTERNATIONAL_CODE = "86"

    @pytest.fixture(autouse=True)
    def setup(self):
        """测试前置设置"""
        # 创建加密HTTP客户端
        self.client = EncryptedHTTPClient(
            base_url=self.BASE_URL,
            encryption_enabled=True,
            verify_ssl=False,
            timeout=30,
            headers={
                "User-Agent": "Python/TestClient"
            }
        )

        # 创建JSONPath提取器
        self.extractor = JSONPathExtractor()

        yield

        # 测试后清理
        self.client.close()
        self.extractor.clear_variables()

    def test_login(self):
        """
        测试登录接口

        执行: pytest tests/test_login_api.py::TestLoginAPI::test_login -v -s
        """
        # 构造登录数据
        login_data = {
            "account": self.TEST_ACCOUNT,
            "pwd": self.TEST_PASSWORD,
            "internationalCode": self.TEST_INTERNATIONAL_CODE
        }

        logger.info(f"发送登录请求到: {self.LOGIN_ENDPOINT}")
        logger.info(f"登录数据: {login_data}")

        try:
            # 发送登录请求（自动加密请求，自动解密响应）
            response = self.client.post(
                self.LOGIN_ENDPOINT,
                data=login_data
            )

            # 检查响应状态
            assert response["status_code"] == 200, f"登录失败，状态码: {response['status_code']}"

            # 保存完整响应供后续提取
            self.extractor.save_response("login", response)

            # 使用JSONPath提取关键数据
            logger.info("\n" + "="*50)
            logger.info("提取登录响应数据")
            logger.info("="*50)

            # 提取响应中的多个字段
            extraction_config = {
                "code": "$.data.code",                    # 响应码
                "message": "$.data.msg",                  # 响应消息
                "success": "$.data.success",              # 成功标志
                "token": "$.data.data",                   # Token (在data.data中)
            }

            extracted_data = self.extractor.extract_multiple(response, extraction_config)

            # 打印提取的数据
            logger.info(f"响应码: {extracted_data['code']}")
            logger.info(f"响应消息: {extracted_data['message']}")
            logger.info(f"成功标志: {extracted_data['success']}")

            # Token可能很长，只显示前50个字符
            token = extracted_data.get('token', '')
            token_display = str(token)[:50] + "..." if token and len(str(token)) > 50 else str(token)
            logger.info(f"Token: {token_display}")

            # 验证登录成功
            assert extracted_data['code'] == 20000, f"业务错误: {extracted_data['message']}"
            assert extracted_data['token'] is not None, "Token不应为空"

            logger.info("✓ 登录成功！")

        except Exception as e:
            pytest.fail(f"测试失败: {e}")

    def test_logout(self):
        """
        测试登出接口（先登录获取token，再登出）

        执行: pytest tests/test_login_api.py::TestLoginAPI::test_logout -v -s
        """
        # 先登录获取token
        login_data = {
            "account": self.TEST_ACCOUNT,
            "pwd": self.TEST_PASSWORD,
            "internationalCode": self.TEST_INTERNATIONAL_CODE
        }

        try:
            # Step 1: 登录获取token
            logger.info("Step 1: 登录获取token")
            logger.info(f"登录URL: {self.LOGIN_ENDPOINT}")

            response = self.client.post(
                self.LOGIN_ENDPOINT,
                data=login_data
            )

            assert response["status_code"] == 200, f"登录失败，状态码: {response['status_code']}"

            # 提取token
            token = self.extractor.extract(response, "$.data.data", "token")
            assert token is not None, "Token不应为空"

            token_display = str(token)[:50] + "..." if token and len(str(token)) > 50 else str(token)
            logger.info(f"获取到Token: {token_display}")

            # Step 2: 使用token调用登出接口
            logger.info("\n" + "="*50)
            logger.info("Step 2: 使用Token调用登出接口")
            logger.info("="*50)

            # 构造请求头，将token放到TK字段
            logout_headers = {
                "TK": str(token)  # Token放到TK字段
            }
            logger.info(f"请求头 TK: {token_display}")

            # 调用登出接口
            logger.info(f"登出URL: GET {self.LOGOUT_ENDPOINT}")

            logout_response = self.client.get(
                self.LOGOUT_ENDPOINT,
                headers=logout_headers
            )

            logger.info(f"登出响应状态码: {logout_response['status_code']}")

            # 提取登出响应数据
            if logout_response['status_code'] == 200 and logout_response.get('data'):
                logout_data = self.extractor.extract_multiple(logout_response, {
                    "logout_code": "$.data.code",
                    "logout_msg": "$.data.msg",
                    "logout_success": "$.data.success"
                })

                logger.info(f"登出响应码: {logout_data.get('logout_code')}")
                logger.info(f"登出消息: {logout_data.get('logout_msg')}")
                logger.info(f"登出成功: {logout_data.get('logout_success')}")

                # 验证登出成功
                assert logout_data.get('logout_code') == 20000, f"登出失败: {logout_data.get('logout_msg')}"
                logger.info("✓ 登出成功！")
            else:
                logger.warning(f"登出响应异常: {logout_response}")

        except Exception as e:
            pytest.fail(f"测试失败: {e}")


def main():
    """
    主函数 - 直接运行脚本时执行
    使用方法: python tests/test_login_api.py
    """
    import warnings
    warnings.filterwarnings("ignore")

    print("=" * 60)
    print("登录并调用登出接口示例")
    print("=" * 60)

    # 创建客户端和提取器
    client = EncryptedHTTPClient(
        base_url="https://bofa.ye81s.com",
        encryption_enabled=True,
        verify_ssl=False,
        timeout=30
    )

    extractor = JSONPathExtractor()

    try:
        # 登录数据
        login_data = {
            "account": "18818881888",
            "pwd": "O4zAs9Mz4aoYOirIST4Xyg==",
            "internationalCode": "86"
        }

        print(f"\n1. 发送登录请求...")
        print(f"   URL: {client.base_url}/cdb/api/auth/login_v1")
        print(f"   数据: {login_data}")

        # 发送登录请求
        response = client.post("/cdb/api/auth/login_v1", data=login_data)

        print(f"\n2. 响应状态: {response['status_code']}")

        if response['status_code'] == 200:
            # 提取关键数据
            print(f"\n3. 提取响应数据...")

            # 使用JSONPath提取
            code = extractor.extract(response, "$.data.code", "code")
            msg = extractor.extract(response, "$.data.msg", "message")
            success = extractor.extract(response, "$.data.success", "success")
            token = extractor.extract(response, "$.data.data", "token")

            print(f"   响应码: {code}")
            print(f"   消息: {msg}")
            print(f"   成功: {success}")

            token_display = str(token)[:50] + "..." if token and len(str(token)) > 50 else str(token)
            print(f"   Token: {token_display}")

            if token:
                # 调用登出接口
                print(f"\n4. 使用Token调用登出接口...")
                print(f"   URL: {client.base_url}/cdb/api/auth/logout")
                print(f"   请求头 TK: {token_display}")

                # 构造请求头（TK字段）
                logout_headers = {
                    "TK": str(token)
                }

                # 发送登出请求
                logout_response = client.get(
                    "/cdb/api/auth/logout",
                    headers=logout_headers
                )

                print(f"\n5. 登出响应状态: {logout_response['status_code']}")

                if logout_response['status_code'] == 200 and logout_response.get('data'):
                    # 提取登出响应
                    logout_code = extractor.extract(logout_response, "$.data.code")
                    logout_msg = extractor.extract(logout_response, "$.data.msg")

                    print(f"   登出响应码: {logout_code}")
                    print(f"   登出消息: {logout_msg}")

                    if logout_code == 20000:
                        print("   ✓ 登出成功！")

            # 展示所有保存的变量
            print(f"\n6. 所有已保存的变量:")
            for name, value in extractor.get_all_variables().items():
                display_value = str(value)[:50] + "..." if isinstance(value, str) and len(value) > 50 else value
                print(f"   ${{{name}}}: {display_value}")

        else:
            print(f"登录失败，状态码: {response['status_code']}")

    except Exception as e:
        print(f"\n错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        client.close()
        print("\n" + "=" * 60)
        print("示例完成")
        print("=" * 60)


if __name__ == "__main__":
    main()